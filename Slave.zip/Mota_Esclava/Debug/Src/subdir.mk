################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/adc.c \
../Src/gpio.c \
../Src/main.c \
../Src/rtc.c \
../Src/spi.c \
../Src/stm32l4xx_hal_msp.c \
../Src/stm32l4xx_it.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/system_stm32l4xx.c 

OBJS += \
./Src/adc.o \
./Src/gpio.o \
./Src/main.o \
./Src/rtc.o \
./Src/spi.o \
./Src/stm32l4xx_hal_msp.o \
./Src/stm32l4xx_it.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/system_stm32l4xx.o 

C_DEPS += \
./Src/adc.d \
./Src/gpio.d \
./Src/main.d \
./Src/rtc.d \
./Src/spi.d \
./Src/stm32l4xx_hal_msp.d \
./Src/stm32l4xx_it.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/system_stm32l4xx.d 


# Each subdirectory must supply rules for building sources it contributes
Src/adc.o: ../Src/adc.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/adc.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/gpio.o: ../Src/gpio.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/gpio.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/main.o: ../Src/main.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/main.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/rtc.o: ../Src/rtc.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/rtc.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/spi.o: ../Src/spi.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/spi.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/stm32l4xx_hal_msp.o: ../Src/stm32l4xx_hal_msp.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/stm32l4xx_hal_msp.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/stm32l4xx_it.o: ../Src/stm32l4xx_it.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/stm32l4xx_it.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/syscalls.o: ../Src/syscalls.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/syscalls.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/sysmem.o: ../Src/sysmem.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/sysmem.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/system_stm32l4xx.o: ../Src/system_stm32l4xx.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"Src/system_stm32l4xx.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

