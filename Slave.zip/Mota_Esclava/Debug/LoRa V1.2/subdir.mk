################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../LoRa\ V1.2/RF95.c 

OBJS += \
./LoRa\ V1.2/RF95.o 

C_DEPS += \
./LoRa\ V1.2/RF95.d 


# Each subdirectory must supply rules for building sources it contributes
LoRa\ V1.2/RF95.o: ../LoRa\ V1.2/RF95.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32L412xx -DDEBUG -c -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/Cap Soil Moisture V1.2" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Device/ST/STM32L4xx/Include -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Esclava/DS18B20" -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -IC:/Users/Alejandro/STM32Cube/Repository/STM32Cube_FW_L4_V1.14.0/Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"LoRa V1.2/RF95.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

