################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
EXECUTABLES := 
OBJS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Cap\ Soil\ Moisture\ V1.2 \
DS18B20 \
Drivers/STM32L4xx_HAL_Driver \
LoRa\ V1.2 \
Src \
Startup \

