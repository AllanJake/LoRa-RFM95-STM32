#include "Cap_Soil_v12.h"

uint32_t Cap_Soil_Read(void)
{
	uint32_t read_value = 0;
	
	HAL_ADC_Start(&sens_hum_adc);
	
	HAL_Delay(100);
	
	read_value = HAL_ADC_GetValue(&sens_hum_adc);
	
	HAL_ADC_Stop(&sens_hum_adc);
	
	return read_value;
}


uint32_t Cap_Soil_Read_Percentage(void)
{

	return 0;
}

