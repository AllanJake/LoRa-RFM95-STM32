#ifndef _CAP_SOIL_
#define _CAP_SOIL_

#include <stm32l4xx.h>
#include "stm32l4xx_hal_adc.h"
#include "stm32l4xx_hal_def.h"


#define equation 1

extern ADC_HandleTypeDef hadc2;
#define sens_hum_adc hadc2

uint32_t Cap_Soil_Read(void);
uint32_t Cap_Soil_Read_Percentage(void);


#endif

