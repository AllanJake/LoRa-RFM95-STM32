#include "18B20.h"


void convertDs18b20(void) 
{ 
    resetOnewire(); 
    wOnewire(SKIP_ROM_CMD_BYTE); 
    wOnewire(CONVERT_T_CMD); 
}


uint8_t* readID(void) 
{ 
	uint8_t ID[8],i,*p;
	resetOnewire(); 
	wOnewire(READ_ROM_CMD_BYTE);
	for(i=0;i<8;i++)
	{ID[i]=rOnewire();}
	p=ID;
	return p;
}



float DS18B20_readTemp(void) 
{ 
	uint8_t temp_LSB, temp_MSB;
	uint16_t temp, mask = 1;
	float result = 0.0, aux = 0.0;
	
	convertDs18b20();
	
	resetOnewire(); 
	wOnewire(SKIP_ROM_CMD_BYTE); 
	wOnewire(READ_SCRATCHPAD_CMD);
 	
	temp_LSB = rOnewire(); 
	temp_MSB = rOnewire(); 
	
	temp = ((temp_MSB << 8) | temp_LSB);
	
	for (int k = -4; k < 7; k++) {
		if (temp & mask) {
			aux = pow(2,k);
			result += aux;
		}
		mask = mask << 1;
	}

	return result;
}


float avg = 0.0;
float DS18B20_read_AVG_Temp(int measures)
{
	uint8_t temp_LSB, temp_MSB;
	uint16_t temp, mask = 1;
	float result = 0.0, aux = 0.0;
	
	for(int i = 0; i < measures; i++)
	{
		result = 0.0;
		
		convertDs18b20();
		
		resetOnewire(); 
		wOnewire(SKIP_ROM_CMD_BYTE); 
		wOnewire(READ_SCRATCHPAD_CMD);
		
		temp_LSB = rOnewire(); 
		temp_MSB = rOnewire(); 
		
		temp = ((temp_MSB << 8) | temp_LSB);
		
		for (int k = -4; k < 7; k++) 
		{
			if (temp & mask) 
			{
				aux = pow(2,k);
				result += aux;
			}
			
			mask = mask << 1;
		}
		
		avg = avg + result;
	}
	
	avg = avg / measures;
	
	return avg;
}
