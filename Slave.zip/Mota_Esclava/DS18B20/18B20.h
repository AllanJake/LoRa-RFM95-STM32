#ifndef _18B20_H
#define _18B20_H

#include <stm32l4xx.h>
#include "OneWire.h"
#include <math.h>

#define READ_ROM_CMD_BYTE		0x33
#define SKIP_ROM_CMD_BYTE		0xCC

#define CONVERT_T_CMD			0x44
#define READ_SCRATCHPAD_CMD		0xBE

void convertDs18b20(void);
uint8_t* readID(void);
float DS18B20_readTemp(void);
float DS18B20_read_AVG_Temp(int measures);

#endif /*_18B20_H*/

