#ifndef _ONEWIRE_H
#define _ONEWIRE_H

#include <stm32l4xx.h>

#define GPIO_Pin		GPIO_PIN_1
#define GPIO_Port		GPIOA

#define SET_DQ() 		HAL_GPIO_WritePin(GPIO_Port, GPIO_Pin, GPIO_PIN_SET)
#define CLR_DQ() 		HAL_GPIO_WritePin(GPIO_Port, GPIO_Pin, GPIO_PIN_RESET)

#define GET_DQ() 		HAL_GPIO_ReadPin(GPIO_Port, GPIO_Pin)

void Onewire_Enable_GPIO_Port(void);
void Onewire_OUT_PULL_UP(void);
void Onewire_OUT_FLOATING(void);
void Onewire_IN_FLOATING(void);
void Onewire_IN_PULL_UP(void);
void delay_us(uint16_t us);
void resetOnewire(void) ;
uint8_t rOnewire(void);
void wOnewire(uint8_t data);

#endif /*_ONEWIRE_H*/
