/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "rtc.h"
#include "spi.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "RF95.h"
#include "dwt_stm32_delay.h"
#include "18B20.h"
#include "Cap_Soil_V12.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define Measure_Period	10
#define N_Measurements	(60 / Measure_Period + 1)
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern RTC_HandleTypeDef hrtc;
RTC_TimeTypeDef sTime = {0};
RTC_DateTypeDef sDate = {0};
RTC_AlarmTypeDef sAlarm = {0};
uint8_t Hours_o = 0;
uint8_t Minutes_o = 0;
uint8_t Seconds_o = 0;

uint8_t _buf[RH_RF95_MAX_PAYLOAD_LEN];

float Temp[24] = {0};
float read_temp[N_Measurements] = {0};

uint16_t Hum[24] = {0};
uint16_t read_hum[N_Measurements] = {0};

float Bat[24] = {0};

HAL_StatusTypeDef error_code = HAL_OK;
int n = 0;

volatile bool Alarm_Flag = 1;
bool ID_Correct = 0;

uint8_t i = 0, num_of_meas_made = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Set_RTC_from_master(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_SPI1_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */
	DWT_Delay_Init();

	Set_RTC_from_master();

//	read_temp[i] = DS18B20_readTemp();
//
//	read_hum[i] = Cap_Soil_Read();
//
//	i++;





  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//	HAL_PWR_EnterSLEEPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);

	//Cuando se de una alarma
	if(Alarm_Flag)
	{
		//Reseteamos el flag de alarma
		Alarm_Flag = 0;

		//Si estamos en el bucle de leer cada 10 segundos
		if(i <= N_Measurements)
		{
			//Leemos la temperatura y humedad
			read_temp[i] = DS18B20_readTemp();
			read_hum[i] = Cap_Soil_Read();

			i++;

			if(i == 0)
			{
				//Leemos los valores de la fecha y la hora
				HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
				HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

				//Guardamos los valores como valores iniciales
				Hours_o = sTime.Hours;
				Minutes_o = sTime.Minutes;
				Seconds_o = sTime.Seconds;

				sAlarm.AlarmTime.Seconds = sTime.Seconds + Measure_Period;
				//Realizamos el enascaramiento del Dateweek, Hours y minutes para que no los tenga en cuenta en la alarma
				sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY|RTC_ALARMMASK_HOURS
										|RTC_ALARMMASK_MINUTES;
				if(sAlarm.AlarmTime.Seconds >= 60)
					sAlarm.AlarmTime.Seconds = sAlarm.AlarmTime.Seconds - 60;
			}
			else
			{
				//Fijamos la alarma para dentro de X segundos (Measure_Period)
				sAlarm.AlarmTime.Seconds += Measure_Period;
				sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY|RTC_ALARMMASK_HOURS
							  |RTC_ALARMMASK_MINUTES;
				if(sAlarm.AlarmTime.Seconds >= 60)
					sAlarm.AlarmTime.Seconds = sAlarm.AlarmTime.Seconds - 60;
			}

			HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);
		}
		//Si ya hemos realizado las medidas cada 10 segundos durante un minuto
		else if(i > N_Measurements)
		{
			//Calculamos el valor medio de las medidas realizadas
			for(i = 0; i < N_Measurements; i++)
			{
				Temp[num_of_meas_made] += read_temp[i];
				Hum[num_of_meas_made] += read_hum[i];
			}

			Temp[num_of_meas_made] /= N_Measurements;
			Hum[num_of_meas_made] /= N_Measurements;

			//Medimos la batería
			HAL_ADC_Start(&hadc1);
			HAL_Delay(100);
			Bat[num_of_meas_made] = (float)(HAL_ADC_GetValue(&sens_hum_adc) * 3.3F / 4095.0F * 100.F);
			HAL_ADC_Stop(&hadc1);

			//Preparamos el índice num_of_meas_made para la siguiente muestra
			num_of_meas_made++;

			//Fijamos la alarma para que suceda en el mismo minuto y segundo iniciales de la hora siguiente
			sAlarm.AlarmTime.Seconds = Seconds_o;
			sAlarm.AlarmTime.Minutes = Minutes_o;
			sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY|RTC_ALARMMASK_HOURS;

			HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);

			//Reseteamos el índice i para que comience de nuevo a almacenar los valores en la siguiente alarma
			i = 0;
		}
		//Si son las 23:50:15
		else if(sTime.Hours == 23 && sTime.Minutes == 50 && sAlarm.AlarmTime.Seconds >= 15)
		{
			RF95_Slave_Send_to_Master();

			//Reseteamos el número de medidas realizadas
			num_of_meas_made = 0;
			//Ponemos a cero los vectores que contienen las variables medidas
			for(int i =0; i < 24; i++)
			{
				Temp[i] = 0;
				Hum[i] = 0;
				Bat[i] = 0;
			}
			//Eperamos hasta detectar actividad en los canales LoRa
//			while(RF95_waitCAD() != RF95_OK)
//			{
//
//			}
//
//			//Una vez detectada
//			if(RF95_availableTimeout(1000))
//			{
//				//Recibimos el identificador enviado por la mota maestra para saber qué mota debe enviarle los valores medidos
//				RF95_receive(_buf);
//
//				//Comprobamos que el identificador sea el nuestro
//				if(strstr((const char*)_buf, Mota_ID) != 0)
//				{
//					ID_Correct = 1;
//				}
//				else
//				{
//					ID_Correct = 0;
//				}
//			}
//
//			//Si es nuestro identificador
//			if(ID_Correct == 1)
//			{
//				//Enviamos los datos a la mota maestra uno por uno
//				for(int k = 0; k <= num_of_meas_made; k++)
//				{
//					//Los copiamos al buffer con el formato adecuado
//					sprintf((char*)_buf, "%3.4f;%d;%2.4f\n", Temp[k], Hum[k], Bat[k]);
//
//					//Los enviamos por LoRa
//					RF95_send(_buf);
//
//					//Esperamos a que se haya enviado o se cumpla el timeout
//					res = RF95_waitPacketSentTimeout(1500);
//					//Esperamos la confimación de dato correctamente recibido
//					if(res == RF95_OK)
//					{
//						if(RF95_availableTimeout(1000))
//						{
//							RF95_receive(_buf);
//						}
//					}
//					else
//					{
//						break;
//					}
//				}
//
//				//Una vez enviados todos los datos, reseteamos el índice num_of_meas_made para que quede listo para comenzar a guardar datos de nuevo cuando toque
//				num_of_meas_made = 0;
//
//				//Leemos la hora tras haber enviado los datos
//				HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
//
//				//Si el minuto y segundo en el que se supone que se debía medir ya ha pasado
//				if(Minutes_o > sTime.Minutes && Seconds_o > sTime.Seconds)
//				{
//					//Realizamos la primera medida de esta hora
//					read_temp[i] = DS18B20_readTemp();
//					read_hum[i] = Cap_Soil_Read();
//
//					i++;
//
//					//Fijamos la alarma para dentro de 10 segundos
//					sAlarm.AlarmTime.Seconds += Measure_Period;
//					sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY|RTC_ALARMMASK_HOURS
//																|RTC_ALARMMASK_MINUTES;
//					if(sAlarm.AlarmTime.Seconds == 60)
//						sAlarm.AlarmTime.Seconds = sAlarm.AlarmTime.Seconds - 60;
//				}
//				//Si no es así
//				else
//				{
//					//Fijamos la alarma para que suceda en el mismo minuto y segundo próximos en los que debe medir
//					sAlarm.AlarmTime.Seconds = Seconds_o;
//					sAlarm.AlarmTime.Minutes = Minutes_o;
//					sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY|RTC_ALARMMASK_HOURS;
//				}
//			}
		}



		if(sTime.Hours == 23) //Si la alarma ha ocurrido a una hora entre las 23:00 y las 00:00
		{
			//Fijamos la alarma para las 00:00, para enviar los datos al servidor
			sAlarm.AlarmTime.Hours = 0;
			sAlarm.AlarmTime.Minutes = 0;
			sAlarm.AlarmTime.Seconds = 0;
			sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY;
			if(sAlarm.AlarmTime.Seconds == 60)
				sAlarm.AlarmTime.Seconds = sAlarm.AlarmTime.Seconds - 60;

			HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);
		}
	}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 23;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(hrtc);

  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_RTC_AlarmAEventCallback could be implemented in the user file
   */
	Alarm_Flag = 1;
}


void Set_RTC_from_master(void)
{
	uint8_t buffer[20] = {0};

	RF95_Slave_Receive_from_Master(buffer);

	sDate.Year = (buffer[0] - '0') * 10 + (buffer[1] - '0');
	sDate.Month = (buffer[3] - '0') * 10 + (buffer[4] - '0');
	sDate.Date = (buffer[6] - '0') * 10 + (buffer[7] - '0');
	if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
	{
	Error_Handler();
	}

	sTime.Hours = (buffer[9] - '0') * 10 + (buffer[10] - '0');
	sTime.Minutes = (buffer[12] - '0') * 10 + (buffer[13] - '0');
	sTime.Seconds = (buffer[15] - '0') * 10 + (buffer[16] - '0');
	if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
	{
	Error_Handler();
	}
}






/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
