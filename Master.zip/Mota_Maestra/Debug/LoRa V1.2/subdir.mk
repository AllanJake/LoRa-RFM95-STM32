################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../LoRa\ V1.2/RF95.c 

OBJS += \
./LoRa\ V1.2/RF95.o 

C_DEPS += \
./LoRa\ V1.2/RF95.d 


# Each subdirectory must supply rules for building sources it contributes
LoRa\ V1.2/RF95.o: ../LoRa\ V1.2/RF95.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DDEBUG -DSTM32L432xx -c -I../Inc -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Maestra/SIM800L" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Maestra/LoRa V1.2" -I"C:/Users/Alejandro/STM32CubeIDE/workspace_1.0.2/Mota_Maestra/SD FATFS" -I../Drivers/CMSIS/Include -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Middlewares/Third_Party/FatFs/src -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -Og -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"LoRa V1.2/RF95.d" -MT"$@"  -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

