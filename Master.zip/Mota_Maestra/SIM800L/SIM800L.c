#include "SIM800L.h"

#define Serial_Port 0

#if Serial_Port
#include "Serial_Port.h"
#endif


struct SIM800_Struct SIM800;
SIM800_StatusTypedef SIM800_Err = SIM800_OK;
HAL_StatusTypeDef err = HAL_OK;

extern FATFS fs;

SIM800_StatusTypedef SIM800_Init(void)
{
	SIM800_Err = SIM800_Reset();
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	do
	{
		SIM800_Err = SIM800_Set_Bearer_Config();
	} 
	while(SIM800_Err != SIM800_OK);
	
	return SIM800_OK;
}

int WeekDay (int year, int month, int day) {
 
  int a, y, m, weekday;
 
  a = (14-month) / 12;
  y = year - a;
  m = month + (12*a) - 2;
  weekday = (day + y + (y/4) - (y/100) + (y/400) + (31*m) / 12) % 7;
  if (weekday==0) {
    weekday=7;
  }
 
  return weekday;
}


/*
time_date_buff[0] = year;
time_date_buff[1] = month;
time_date_buff[2] = day;

time_date_buff[3] = hour;
time_date_buff[4] = minute;
time_date_buff[5] = second;
*/

SIM800_StatusTypedef SIM800_Get_Time_Date_GPRS(int* time_date_buff)
{
	int change_hour_day_start = 0,
		change_hour_day_end = 0;
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=1,1\r\n", 1, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=2,1\r\n", 1, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	
	SIM800_Err = SIM800_Send_AT("AT+CIPGSMLOC=2,1\r\n", 1, 20000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	time_date_buff[0] = 1000 * (SIM800.buffer[16] - '0') + 100 * (SIM800.buffer[17] - '0')	+ 10 * (SIM800.buffer[18] - '0') + (SIM800.buffer[19] - '0');
	time_date_buff[1] = 10 * (SIM800.buffer[21] - '0') + (SIM800.buffer[22] - '0');
	time_date_buff[2] = 10 * (SIM800.buffer[24] - '0') + (SIM800.buffer[25] - '0');
	
	time_date_buff[3] = 10 * (SIM800.buffer[27] - '0') + (SIM800.buffer[28] - '0');
	time_date_buff[4] = 10 * (SIM800.buffer[30] - '0') + (SIM800.buffer[31] - '0');
	time_date_buff[5] = 10 * (SIM800.buffer[33] - '0') + (SIM800.buffer[34] - '0');
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=0,1\r\n", 1, 3000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	/*==========Spanish adjustment of time==========*/
	change_hour_day_start = WeekDay(time_date_buff[0], 3, 31);
	if(change_hour_day_start != 7)
	{
		change_hour_day_start = 31 - change_hour_day_start;
	}
	else
	{
		change_hour_day_start = 31;
	}
	
	
	change_hour_day_end = WeekDay(time_date_buff[0], 10, 31);
	if(change_hour_day_end != 7)
	{
		change_hour_day_end = 31 - change_hour_day_end;
	}
	else
	{
		change_hour_day_end = 31;
	}
	
	time_date_buff[3]++; //It's GMT+1 in spain
	
	if((((time_date_buff[1] == 3) && (time_date_buff[2] >= change_hour_day_start)) || 
		 ((time_date_buff[1] == 10) && (time_date_buff[2] < change_hour_day_end)) || 
		 ((time_date_buff[1] > 3) && (time_date_buff[1] < 10))))
	{
		time_date_buff[3]++; //And we add 1 hour if we are in summer time
	}
	
	return SIM800_OK;
}

void SIM800_Clear_Buffer(void)
{
	
}


SIM800_StatusTypedef SIM800_Restore(void)
{
	SIM800_Err = SIM800_Send_AT("ATZ0\r\n", 1, 20000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	return SIM800_OK;
}


SIM800_StatusTypedef SIM800_Reset(void)
{
	char aux_buffer[50] = {0};
	
	HAL_GPIO_WritePin(SIM800L_RST_GPIO_Port, SIM800L_RST_Pin, GPIO_PIN_RESET);
	HAL_Delay(3100);
	HAL_GPIO_WritePin(SIM800L_RST_GPIO_Port, SIM800L_RST_Pin, GPIO_PIN_SET);
	HAL_Delay(3500);
	 
	while(strstr((const char*)SIM800.buffer, "OK") == 0)
	{
		HAL_Delay(1000);
		SIM800_Send_AT("AT\r\n", 1, Default_Time);
	}
	
	strcpy(aux_buffer, "AT+IPR=");
	strcat(aux_buffer, Baud_Rate);
	strcat(aux_buffer, "\r\n");
	SIM800_Err = SIM800_Send_AT(aux_buffer, 1, 20000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CMEE=1\r\n", 1, 20000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux_buffer, "AT+CPIN=\"");
	strcat(aux_buffer, PIN);
	strcat(aux_buffer, "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux_buffer, 1, 5000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CPIN?\r\n", 1, 5000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(500);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	return SIM800_OK;
}


SIM800_StatusTypedef SIM800_Send_AT(char* cmd, int num_answ, uint32_t Max_Time)
{
	char tx_buffer[SIM800_Buff_Max_Size] = {0};
	uint32_t tick = HAL_GetTick();
	
	for(int i = 0; i < SIM800_Buff_Max_Size; i++)
	{
		SIM800.buffer[i] = 0;
	}
	HAL_Delay(1000);
	
	SIM800.rx_index = 0;
	SIM800.rx_data = 0;
	SIM800.prev_data = 0;
	SIM800.num_of_answ = num_answ;
	strcpy(tx_buffer, cmd);
	
	
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)tx_buffer, sizeof(tx_buffer), 50000);
	SIM800.Ongoing_flag = 1;
	HAL_Delay(10);
	err = HAL_UART_Receive_IT(&SIM800_uart, (uint8_t *)&SIM800.rx_data, 1);
	
	while((SIM800.Ongoing_flag == 1) && (HAL_GetTick() - tick < Max_Time))
	{
//		HAL_Delay(1);
	}	
	

	
	if((strstr((const char*)SIM800.buffer, ">") != NULL) || (strstr((const char*)SIM800.buffer, "DOWNLOAD") != NULL))
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_OK;
	}
	if((SIM800.Ongoing_flag == 0) && (strstr((const char*)SIM800.buffer, "CME") != NULL))
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_CME_ERROR;
	}
	else if((SIM800.Ongoing_flag == 0) && (strstr((const char*)SIM800.buffer, "OK") != NULL || strstr((const char*)SIM800.buffer, "+") != NULL))
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_OK;
	}
	else if(strstr((const char*)SIM800.buffer, "ERROR") != NULL)
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_ERROR;
	}
	else if(SIM800.Ongoing_flag == 0)
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_STOP;
	}
	else if(SIM800.Ongoing_flag == 1)
	{
		SIM800.Ongoing_flag = 0;
		return SIM800_TIMEOUT;
	}
	else return SIM800_NONE;
}


void SIM800_Callback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART1)
	{
		if(SIM800.rx_index > SIM800_Buff_Max_Size)
		{
			SIM800.rx_index = 0;
		}
		
		switch(SIM800.rx_data)
		{
			case '\r':
				if((SIM800.count == 0) || (SIM800.count % 2 == 0) || (SIM800.prev_data == '\n'))
				{
					SIM800.count++;
				}
			
				if(strstr((const char*)SIM800.buffer, "AT") != NULL)
				{
					for(int i = 0; i < SIM800.rx_index; i++)
					{
						SIM800.buffer[i] = 0;
					}
					SIM800.count = 0;
					SIM800.rx_index = 0;
					SIM800.prev_data = 0;
				}
				
				if(SIM800.count >= 1 && SIM800.count < 3)
				{
					SIM800.rx_index = 0;
				}
				
				SIM800.buffer[SIM800.rx_index++] = SIM800.rx_data;
				SIM800.prev_data = SIM800.rx_data;
			break;
			
			case '\n':
				if((SIM800.prev_data == '\r') && (SIM800.count % 2 == 1))
				{
					if(SIM800.count == 3)
					{
						SIM800.count = 0;
						SIM800.num_of_answ--;
					}
					else
					{
						SIM800.count++;
					}
				}
				
				if(strstr((const char*)SIM800.buffer, "AT") != NULL)//&& ((prev_data == '\r' && SIM800_count == 1) || SIM800_count == 3)
				{
					for(int i = 0; i < SIM800.rx_index; i++)
					{
						SIM800.buffer[i] = 0;
					}
					SIM800.count = 0;
					SIM800.rx_index = 0;
					SIM800.prev_data = 0;
				}
				
				SIM800.buffer[SIM800.rx_index++] = SIM800.rx_data;
				SIM800.prev_data = SIM800.rx_data;
				
				if(SIM800.num_of_answ == 0)
				{
					SIM800.count = 0;
					SIM800.rx_index = 0;
					SIM800.Ongoing_flag = 0;
				}
			break;
				
			default:
				if(SIM800.count == 2)
				{
					SIM800.buffer[SIM800.rx_index++] = SIM800.rx_data;
				}
			break;
		}
		
		
		if(SIM800.Ongoing_flag == 1)
		{
			HAL_UART_Receive_IT(&SIM800_uart, (uint8_t *)&SIM800.rx_data, 1);
		}		
	}
}


SIM800_StatusTypedef SIM800_Set_Bearer_Config(void)
{
	char aux[60];
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=3,1,\"Contype\",\"GPRS\"\r\n", 1, 3000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(800);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, "AT+SAPBR=3,1,\"APN\",\"");
	strcat(aux, APN);
	strcat(aux, "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, 3000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, "AT+SAPBR=3,1,\"USER\",\"");
	strcat(aux, USER);
	strcat(aux, "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, 3000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, "AT+SAPBR=3,1,\"PWD\",\"");
	strcat(aux, PWD);
	strcat(aux, "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, 3000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=1,1\r\n", 1, 3000); //Abre la conexión GPRS
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(800);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=2,1\r\n", 1, 3000); //Consulta la configuración GPRS
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(800);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	do
	{
		SIM800_Err = SIM800_Send_AT("AT+SAPBR=0,1\r\n", 1, 3000); //Cierra la configuración GPRS
	}
	while(SIM800_Err != SIM800_OK);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(800);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	return SIM800_OK;
}




/*================FUNCI�N FTP================
Funci�n empleada para enviar datos mediante el protocolo FTP desde una tarjjeta de memoria.
Comandos AT empleados:
+ AT+SAPBR=<cmd_type>,<Status>,|<ConParamTag>,<ConParamValue>. Donde:
	- <cmd_type>:   		0 -> Cerrar la configuraci�n
											1 -> Abrir la configuraci�n
											2 -> Consultar la configuraci�n
											3 -> Establecer los par�metros de la configuraci�n
											4 -> Obtener los par�metros de la configuraci�n
	- <Status>:  	  		0 -> Conectando
											1 -> Conectado
											2 -> Desconectando
											3 -> Desconectado
	- <ConParamTag>:		"Contype" -> Establece el tipo de conexi�n a internet
											"APN" -> Establecer el nombre del punto de acceso
											"USER" -> Nombre de usuario
											"PWD" -> Contrase�a											
	- <ConParamValue>:	"GPRS" -> Establece la conexi�n GPRS	
+ AT+FTPCID: establece el perfil de conexi�n FTP. Los perfiles son configurados mediante el comando AT+SAPBR.
+ AT+FTPSERV: establece la direcci�n del servidor FTP. La direcci�n IP puede ser un n�mero de 32 bits en notaci�n decimal
	separado por puntos (xxx.xxx.xxx.xxx) o una cadena de texto alfanum�rica ASCII de 49 car�cteres si DNS est� activada.	
+ AT+FTPPORT: establece el puerto de conexi�n con el servidor FTP, pudiendo ser del 1 al 65535. Por defecto es el 21.
+ AT+FTPUN: establece el nombre de usuario para la sesi�n FTP. El nombre puede ser una cadena de texto alfanum�rica ASCII de hasta 49 car�cteres.
+ AT+FTPPW: establece la contrase�a para la sesi�n FTP. La contrase�a puede ser una cadena de texto alfanum�rica ASCII de hasta 49 car�cteres.
+ AT+FTPPUTNAME: establece el nombre que tendr� el archivo que enviamos al servidor FTP. El nombre puede ser una cadena de texto alfanum�rica 
	ASCII de hasta 99 car�cteres.
+ AT+FTPPUTPATH: establece el nombre de la ruta donde se guardar� el archivo enviado al servidor FTP. El nombre puede ser una cadena de texto alfanum�rica 
	ASCII de hasta 49 car�cteres.
+ AT+FTPPUT: env�a el contenido del archivo. 1 -> Abre la sesi�n FTP.
																						 2 -> Escribe los datos a enviar al servidor.
===========================================*/
SIM800_StatusTypedef SIM800_FTP(char* file_name)
{
	FIL file;
	int len = 0, len2 = 0;
	char buffer[100] ={1};
	char aux[60];
	
	SIM800_Err = SIM800_Send_AT("AT+CGATT=1\r\n", 1, 10000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	//=====Conexión a APN=====
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=1,1\r\n", 1, 1900); //Abre la conexión GPRS
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif

	SIM800_Err = SIM800_Send_AT("AT+SAPBR=2,1\r\n", 2, 1900); //Consulta la configuración GPRS
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	//=====Configuración FTP=====
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=1,1\r\n", 1, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPCID=1\r\n", 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, "AT+FTPSERV=\"");
	strcat(aux,IP_Server);
	strcat(aux, "\"\r\n");
//	len = strlen("AT+FTPSERV=\"");
//	strcpy(&aux[len], IP_Server);
//	len += strlen(IP_Server);
//	strcpy(&aux[len], "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPPORT=21\r\n", 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPUN=\"AlejandroMartinez\"\r\n", 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPPW=\"Alejandro01\"\r\n", 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	//=====Envio de archivos al servidor=====	
	strcpy(aux, "AT+FTPPUTNAME=\"");
	strcat(aux, file_name);
	strcat(aux, "\"\r\n");
//	len = strlen("AT+FTPPUTNAME=\"");
//	strcpy(&aux[len], file_name);
//	len += strlen(file_name);
//	strcpy(&aux[len], "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPPUTPATH=\"/\"\r\n", 1, Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+FTPPUT=1\r\n", 2, 75000);
	if(strstr((const char*)SIM800.buffer, ": 1,1,") == NULL)
	{
		return SIM800_ERROR_FTPPUT;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(aux);
	#endif
	
//	SIM800_Err = SIM800_Send_AT("AT+FTPPUT=2,1000\r\n", 75000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
	
//	if(f_mount(&fs, "", 0) != FR_OK)
//    return SIM800_ERROR_FTPPUT;
	
	if(f_open(&file, file_name, FA_OPEN_ALWAYS | FA_READ | FA_WRITE) != FR_OK)
		return SIM800_ERROR_OPEN_FILE;
	
	strcpy(aux, "AT+FTPPUT=2,");
	len = strlen("AT+FTPPUT=2,");
	f_gets(buffer, Line_size, &file);
	
	while(buffer[0] != 0)
	{
		len2 = strlen(buffer);
		sprintf(&aux[len],"%d\r\n", len2);
		SIM800_Err = SIM800_Send_AT(aux, 1, 75000);
		if(SIM800_Err != SIM800_OK)
		{
			return SIM800_Err;
		}
		HAL_Delay(1000);
		#if Serial_Port
		_print(SIM800_buffer);
		#endif
		
		SIM800_Err = SIM800_Send_AT(buffer, 1, 75000);
		if(SIM800_Err != SIM800_OK)
		{
			return SIM800_Err;
		}
		HAL_Delay(1000);
		#if Serial_Port
		_print(SIM800_buffer);
		#endif
		
		strcpy(aux, "AT+FTPPUT=2,");
		len = strlen("AT+FTPPUT=2,");
		f_gets(buffer, Line_size, &file);
	}
	f_close(&file);
//	if(f_mount(0, "", 0) != FR_OK)
//    return SIM800_ERROR_FTPPUT;
	
	SIM800_Err = SIM800_Send_AT("AT+FTPPUT=2,0\r\n", 2, 75000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+SAPBR=0,1\r\n", 2, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(1000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	return SIM800_OK;
}


SIM800_StatusTypedef SIM800_Send_SMS(char* number, char* text_message)
{
	char aux[512];
	
	SIM800_Err = SIM800_Send_AT("AT\r\n", 1, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CMGF=1\r\n", 1, 1900);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, "AT+CMGS=\"");
	strcat(aux, number);
	strcat(aux, "\"\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 2, 60000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(3000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	strcpy(aux, text_message);
	strcat(aux, "\r\n");
//	len = strlen(text_message);
//	strcpy(&aux[len], "\r\n");
	SIM800_Err = SIM800_Send_AT(aux, 1, 60000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(3000);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	return SIM800_OK;
}


/*================FUNCI�N HORA================
Esta funci�n nos permite obtener la hora del servidor de Domoticz. Comandos empleados:
+ AT+CIPSHUT: desactiva el contexto PDP del GPRS.
+ AT: comprueba el estado del m�dulo.
+ AT+CIPMUX: habilita el tipo de conexi�n IP. 1 -> M�ltiple
																							0 -> Una sola
+ AT+CGATT: 1 -> Habilita el servicio GPRS
						0 -> Deshabilita el servicio GPRS
+ AT+CSTT: Se establece el APN, usuario y contrase�a.
+ AT+CIICR: inicia ua conexi�n inal�mbrica mediante GPRS.
+ AT+CIFSR: obtiene la direcci�n IP local.
+ AT+CDNSGIP: consulta la direcci�n IP del nombre del dominio.
+ AT+CIPSTART: 	especifica el canal de conexi�n (0-5), el tipo de protocolo (TCP/UDP), la
	direcci�n IP o el nombre del dominio y el n�mero de puerto.
+ AT+CIPSEND: se prepara el env�o de datos. Se tiene que especificar el n�mero de canal asignado
	en el comando anterio.
===========================================*/
//SIM800_StatusTypedef SIM800_Get_Time_Server(char* hora)
//{
//	int len = 0, len2 = 0;
//	char aux[255];
//	int intentos = 0;
//	
//	SIM800_Err = SIM800_Send_AT("AT+CIPSHUT\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+CIPMUX=0\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+CGATT=1\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	
//	strcpy(aux, "AT+CSTT=\"");
//	len = strlen("AT+CSTT=\"");
//	strcpy(&aux[len], APN);
//	len += strlen(APN);
//	strcpy(&aux[len], "\",\"\",\"\"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+CIICR\r\n", Default_Time);
//	intentos ++;
//	HAL_Delay(1000);
////	while(SIM800_Err != SIM800_OK || intentos < 5)
////	{
////		SIM800_Err = SIM800_Send_AT("AT+CIICR\r\n", Default_Time);
////		intentos ++;
////	}
//	
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+CIFSR\r\n", Default_Time);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(1000);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
//	
//	strcpy(aux, "AT+CDNSGIP=\"");
//	strcat(aux, IP_name);
//	strcat(aux, "\"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	do
//	{
//		strcpy(aux, "AT+CIPSTART=0,\"TCP\",\"");
//		len = strlen("AT+CIPSTART=0,\"TCP\",\"");
//		strcpy(&aux[len], IP_name);
//		len += strlen(IP_Server);
//		strcpy(&aux[len], "\",\"80\"\r\n");
//		SIM800_Err = SIM800_Send_AT(aux, Default_Time);
//		if(SIM800_Err == SIM800_ERROR)
//		{
//			return SIM800_Err;
//		}
//		HAL_Delay(1000);
//		#if Serial_Port
//		_print(SIM800_buffer);
//		#endif
//	} 
//	while(SIM800_Err == SIM800_CME_ERROR);
//	
//	do
//	{
//		SIM800_Err = SIM800_Send_AT("AT+CIPSEND\r\n", 645000);
//		
//		if(SIM800_Err == SIM800_ERROR)
//		{
//			return SIM800_Err;
//		}
//		HAL_Delay(1000);
//		#if Serial_Port
//		_print(SIM800_buffer);
//		#endif
//	}
//	while(SIM800_Err == SIM800_CME_ERROR);
//	
//	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"GET http:///json.htm?type=command&param=getSunRiseSet", sizeof("GET /json.htm?type=command&param=getSunRiseSet"), 1000);
//	if(err != HAL_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)" HTTP/1.1\r\n", sizeof(" HTTP/1.1\r\n"), 1000);
//	if(err != HAL_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif	
//	
//	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"HOST: http://tfgamb.ddns.net\r\n", sizeof("HOST: http://tfgamb.ddns.net\r\n"), 1000);
//	if(err != HAL_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif	
//	
//	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"Connection: close\r\n\r\n", sizeof("Connection: close\r\n\r\n"), 1000);
//	if(err != HAL_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif	
//	
//	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"\x1A", sizeof("\x1A"), 1000);
//	if(err != HAL_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(1000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	HAL_Delay(3000);
//	err = HAL_UART_Receive(&SIM800_uart, (uint8_t *)SIM800.buffer, sizeof(SIM800.buffer), 100);
//	
//	SIM800_Err = SIM800_Send_AT("AT+CIPCLOSE\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(3000);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//}


//SIM800_StatusTypedef SIM800_HTTP_GET(char* url)
//{
//	char aux[512];
////	SIM800_StatusTypedef SIM800_Err = SIM800_OK;
//
//	//=====Configuraci�n APN=====
////	SIM800_Set_Bearer_Config();
//
//	SIM800_Err = SIM800_Send_AT("AT+SAPBR=1,1\r\n", 1900);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(500);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	SIM800_Err = SIM800_Send_AT("AT+SAPBR=2,1\r\n", 1900);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(500);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	SIM800_Err = SIM800_Send_AT("AT+HTTPINIT\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+HTTPPARA =\"CID\",1\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	strcpy(aux, "AT+HTTPPARA=\"URL\",\"");
//	strcat(aux, url);
//	strcat(aux, "\"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+HTTPACTION=0\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+HTTPREAD\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//	
//	SIM800_Err = SIM800_Send_AT("AT+HTTPTERM\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	return SIM800_OK;
//}


//SIM800_StatusTypedef SIM800_HTTP_POST(char* url, char* data_format, char* data, int time_lat)
//{
//	int len = 0;
//	char aux[512];
//
//	//=====Configuraci�n APN=====
////	SIM800_Set_Bearer_Config();
//
//	SIM800_Err = SIM800_Send_AT("AT+HTTPINIT\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	SIM800_Err = SIM800_Send_AT("AT+HTTPPARA=\"CID\",1\r\n", 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	memset(aux, 0, sizeof(aux));
//	strcpy(aux, "AT+HTTPPARA=\"URL\",\"");
//	strcat(aux, url);
//	strcat(aux, "\"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, 90000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	memset(aux, 0, sizeof(aux));
//	strcpy(aux, "AT+HTTPPARA=\"CONTENT\",\"");
//	strcat(aux, data_format);
//	strcat(aux, "\"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, 10000);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	memset(aux, 0, sizeof(aux));
//	strcpy(aux, "AT+HTTPDATA=");
//	len = strlen(aux);
//	sprintf(&aux[len], "%d", strlen(data));
//	len = strlen(aux);
//	sprintf(&aux[len], ",%d", time_lat);
//	strcat(aux,"\r\n");
//	SIM800_Err = SIM800_Send_AT(aux, 10000);
//
////	memset(aux, 0, sizeof(aux));
////	strcat(aux,data);
////	strcat(aux,"\r\n");
//	SIM800_Err = SIM800_Send_AT(data, 10000);
//
//	SIM800_Err = SIM800_Send_AT("AT+HTTPACTION=1\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
//	SIM800_Err = SIM800_Send_AT("AT+HTTPTERM\r\n", Default_Time);
//	if(SIM800_Err != SIM800_OK)
//	{
//		return SIM800_Err;
//	}
//	HAL_Delay(100);
//	#if Serial_Port
//	_print(SIM800_buffer);
//	#endif
//
////	SIM800_Err = SIM800_Send_AT("AT+CGATT?\r\n", 10000);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
////
////	SIM800_Err = SIM800_Send_AT("AT+CIPSHUT\r\n", 65000);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
////
//
////	SIM800_Err = SIM800_Send_AT("AT+CIPMUX=0\r\n", Default_Time);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
////
////	SIM800_Err = SIM800_Send_AT("AT+CSTT=\"lowi.private.omv.es\",\"\",\"\"\r\n", Default_Time);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
////
////	SIM800_Err = SIM800_Send_AT("AT+CIICR\r\n", 85000);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
////
////	SIM800_Err = SIM800_Send_AT("AT+CIFSR\r\n", Default_Time);
//////	if(SIM800_Err != SIM800_OK)
//////	{
//////		return SIM800_Err;
//////	}
//////	HAL_Delay(100);
//////	#if Serial_Port
//////	_print(SIM800_buffer);
//////	#endif
////
////	SIM800_Err = SIM800_Send_AT("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n", 160000);
////	if(SIM800_Err != SIM800_OK)
////	{
////		return SIM800_Err;
////	}
////	HAL_Delay(100);
////	#if Serial_Port
////	_print(SIM800_buffer);
////	#endif
//
//
////	SIM800_Err = SIM800_Send_AT("AT+CIPSEND\r\n", 500);
//////	if(SIM800_Err != SIM800_OK)
//////	{
//////		return SIM800_Err;
//////	}
//////	HAL_Delay(100);
//////	#if Serial_Port
//////	_print(SIM800_buffer);
//////	#endif
////	SIM800_Err = SIM800_Send_AT("POST /apps/thingtweet/1/statuses/update HTTP/1.1", 500);
////	SIM800_Err = SIM800_Send_AT("Host: api.thingspeak.com", 500);
////	SIM800_Err = SIM800_Send_AT("Connection: close", 500);
////	SIM800_Err = SIM800_Send_AT("Content-Type: application/x-www-form-urlencoded", 500);
////	SIM800_Err = SIM800_Send_AT("api_key=9LHQMYSSDQBUTMGR&status=I+just+posted+this+from+my+thing!", 500);
////
////	SIM800_Err = SIM800_Send_AT("\x1A", 500);
//
//	
//	return SIM800_OK;
//}


/*
SIM800_Err = SIM800_Send_AT("AT+CGATT?\r\n", 10000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIPSHUT\r\n", 65000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	

	SIM800_Err = SIM800_Send_AT("AT+CIPMUX=0\r\n", Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CSTT=\"lowi.private.omv.es\",\"\",\"\"\r\n", Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIICR\r\n", 85000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIICR\r\n", 85000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIFSR\r\n", Default_Time);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n", 160000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif
	
	SIM800_Err = SIM800_Send_AT("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n", 160000);
	if(SIM800_Err != SIM800_OK)
	{
		return SIM800_Err;
	}
	HAL_Delay(100);
	#if Serial_Port
	_print(SIM800_buffer);
	#endif

	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"AT+CIPSEND\r\n", sizeof("AT+CIPSEND\r\n"), 1000);
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"POST https://api.thingspeak.com/apps/thingtweet/1/statuses/update", sizeof("POST https://api.thingspeak.com/apps/thingtweet/1/statuses/update"), 1000);
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"HTTP/1.1 Host: api.thingspeak.com", sizeof("HTTP/1.1 Host: api.thingspeak.com"), 1000);
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"Content-Type: application/x-www-form-urlencoded", sizeof("Content-Type: application/x-www-form-urlencoded"), 1000);
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"Cache-Control: no-cache", sizeof("Cache-Control: no-cache"), 1000);
	err = HAL_UART_Transmit(&SIM800_uart, (uint8_t*)"api_key=9LHQMYSSDQBUTMGR&status=I+just+posted+this+from+my+Thing!", sizeof("api_key=9LHQMYSSDQBUTMGR&status=I+just+posted+this+from+my+Thing!"), 1000);
*/
