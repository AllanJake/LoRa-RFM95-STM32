#ifndef _SIM800_
#define _SIM800_

//For working with this library we have to enable interrupts with UART and add the SIM800_Callback to the 
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart). If we want to use FTP we have to use SD card files and enable FatFS.
#include "stm32l4xx_hal.h"
#include "stm32l4xx_hal_uart.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "main.h"


#include "fatfs.h"
#include "ff.h"

#define IP_Server	"161.67.130.162"
#define IP_name 	"tfgamb.ddns.net"
#define APN "lowi.private.omv.es"
#define USER	""
#define PWD ""
#define Line_size 100 //bytes
#define aux_len strlen("AT+SAPBR=3,1,\"") + strlen(APN) + strlen("\"\r\n")



#define SIM800_Buff_Max_Size	256
#define Default_Time	10000

#define Baud_Rate	"115200"
#define PIN	"2055"

extern UART_HandleTypeDef huart1;
#define SIM800_uart	huart1

typedef enum{
	SIM800_ERROR,
	SIM800_OK, 
	SIM800_STOP,
	SIM800_ERROR_OPEN_FILE,
	SIM800_TIMEOUT,
	SIM800_NONE,
	SIM800_ERROR_FTPPUT,
	SIM800_CME_ERROR
} SIM800_StatusTypedef;

struct SIM800_Struct{
	volatile uint16_t rx_index;
	volatile uint8_t rx_data, prev_data;
	volatile uint8_t buffer[SIM800_Buff_Max_Size];
	volatile int num_of_answ;
	volatile bool Ongoing_flag;
	volatile int count;
};


SIM800_StatusTypedef SIM800_Init(void);

SIM800_StatusTypedef SIM800_Get_Time_Date_GPRS(int* time_date_buff);

void SIM800_Clear_Buffer(void);

SIM800_StatusTypedef SIM800_Restore(void);

SIM800_StatusTypedef SIM800_Reset(void);

SIM800_StatusTypedef SIM800_Send_AT(char* cmd, int num_answ, uint32_t Max_Time);

void SIM800_Callback(UART_HandleTypeDef *huart);

SIM800_StatusTypedef SIM800_Set_Bearer_Config(void);

SIM800_StatusTypedef SIM800_FTP(char* file_name);

SIM800_StatusTypedef SIM800_Send_SMS(char* number, char* text_message);

SIM800_StatusTypedef SIM800_HTTP_GET(char* url);

SIM800_StatusTypedef SIM800_HTTP_POST(char* url, char* data_format, char* data, int time_lat);

SIM800_StatusTypedef SIM800_Get_Time_Server(char* hora);


/*==========================================================
	Function wich returns the day of the week which is the date introduced
  Monday is 1, Tuesday is 2, ... , Sunday is 7
  ----------------CONGRUENCIA DE ZELLER---------------------
==========================================================*/
int WeekDay (int year, int month, int day);



#endif

