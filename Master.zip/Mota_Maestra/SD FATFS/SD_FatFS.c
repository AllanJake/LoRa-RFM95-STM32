#include "SD_FatFS.h"

volatile FATFS fs;
volatile FATFS *pfs;
FIL fil;
FRESULT fres;
DWORD fre_clust;
uint32_t total, _free;
const TCHAR* ID_path;
BYTE work[_MAX_SS];
bool free_fs_flag = 0;

char file_name[] = "PCE_CO2_Logger/PCE_DD.MM.YYYY_HH.MMam.csv"; //"/PCE_CO2_Logger/PCE_DD.MM.YYYY_HH.MMam.csv"; //43
char dir_name[] =  "PCE_CO2_Logger";
char label_name[] = "PCE_SD";
DWORD total_space, free_space;

bool Linked_Drive = 1;

void Init_FatFS(void)
{
	
//	fs = malloc(sizeof (FATFS));
}


FRESULT SD_Mount(const TCHAR* path)
{
	FRESULT fres = FR_OK;
	
	fres = f_mount((FATFS *)&fs, path, 0);
	
	ID_path = path;
	
	return fres;	
}


FRESULT SD_Unmount(const TCHAR* path)
{
//	if (SD_disk_sync())
//        return FR_INT_ERR;
	FRESULT res = f_mount(0, path, 0);

	return res;
}


FRESULT SD_Format(void)
{
	FRESULT res = FR_NOT_READY;

	
	while(res == FR_NOT_READY)
	{
		if(Linked_Drive == 1)
		{
			res = SD_Mount(ID_path);
			res = f_mkfs(ID_path, FM_ANY, 0, work, sizeof(work));
			res = SD_Unmount(ID_path);
		}
		else 
			return FR_NOT_ENABLED;
	}
		
    return res;
}


bool SD_Check_Label(const TCHAR*label_name)
{
	char get_lable[10] = {0};
	DWORD id;
	
	f_getlabel(ID_path, get_lable, &id);
	
	if(!strcmp(label_name, get_lable))
		return 1;
	else 
		return 0;
}


FRESULT SD_Set_Label(const TCHAR* label_name)
{
	FRESULT fres = FR_OK;
	
	fres = f_setlabel (label_name);
	
	return fres;
}


FRESULT SD_Open(const TCHAR* path, BYTE mode)
{
	FRESULT fres = FR_OK;
	
	fres = f_open(&fil, path, mode);
	
	return fres;
}

	
FRESULT SD_Close(void)
{
	FRESULT fres = FR_OK;
	
	fres = f_close(&fil);
	
	return fres;
}


void SD_Check_Space(void)
{
	FRESULT res = FR_NOT_READY;
	
	DWORD fre_clust;
	
	while(res == FR_NOT_READY)
		res = f_getfree(ID_path, &fre_clust, (FATFS **)&pfs);

	/* Get total sectors and free sectors */
	total_space = (pfs->n_fatent - 2) * pfs->csize;
	free_space = fre_clust * pfs->csize;
}

float percent_ = 0.0F;
float SD_Get_Free_Space_Percentage(void)
{
	FRESULT res = FR_NOT_READY;
	DWORD fre_clust;
	FATFS *fs_;
	
//	SD_Unmount(ID_path);
//	
//	HAL_Delay(200);
//	
//	SD_Mount(ID_path);
	
	while(res == FR_NOT_READY)
		res = f_getfree(ID_path, &fre_clust, &fs_);

	/* Get total sectors and free sectors */
	total_space = (fs_->n_fatent - 2) * fs_->csize;
	free_space = fre_clust * fs_->csize;

	percent_ = (float)((float)free_space * 100.0 / (float)total_space);
	
	if(total_space > 0)
		return percent_;
	else
		return 0.0;
}


float SD_Get_Used_Space_Percentage(void)
{
	return (float)(100.0 - SD_Get_Free_Space_Percentage());
}


int SD_disk_sync()
{
    //Select the card so we're forced to wait for the end of any internal write processes
    if (SD_select()) {
        SD_deselect();
        return 0;
    } else {
        return 1;
    }
}


bool SD_select(void)
{
		uint8_t buff = 0xFF;
	
    //Assert /CS
		HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);

    //Send 8 dummy clocks with DI held high to enable DO
		HAL_SPI_Transmit(&sd_spi, &buff, 1, 100);

    //Wait for up to 500ms for the card to become ready
    if (SD_waitReady(500) == HAL_OK) {
        return true;
    } else {
        //We timed out, deselect and return false
        SD_deselect();
        return false;
    }
}


void SD_deselect()
{
	uint8_t buff = 0xFF;
	
    //Deassert /CS
    HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);

    //Send 8 dummy clocks with DI held high to disable DO
    HAL_SPI_Transmit(&sd_spi, &buff, 1, 100);
}


HAL_StatusTypeDef SD_waitReady(int timeout)
{
    HAL_StatusTypeDef resp;
		uint8_t buff = 0xFF;
		uint32_t tick = HAL_GetTick();

    //Keep sending dummy clocks with DI held high until the card releases the DO line
    do {
        resp = HAL_SPI_Transmit(&sd_spi, &buff, 1, 100);
    } while (resp == HAL_OK && (HAL_GetTick() - tick) < timeout);


    //Return success/failure
    return resp;
}










