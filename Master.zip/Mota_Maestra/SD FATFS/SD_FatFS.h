#ifndef _SD_Card_FatFS_
#define _SD_Card_FatFS_

#include "main.h"
#include "stm32l4xx_hal.h"
#include "stm32l4xx_hal_spi.h"
#include "ff.h"
#include <stdbool.h>
#include <string.h>

extern SPI_HandleTypeDef hspi1;
#define sd_spi hspi1


void Init_FatFS(void);

FRESULT SD_Mount(const TCHAR* path);
FRESULT SD_Unmount(const TCHAR* path);
FRESULT SD_Format(void);
bool SD_Check_Label(const TCHAR*label_name);
FRESULT SD_Set_Label(const TCHAR* label_name);
FRESULT SD_Open(const TCHAR* path, BYTE mode);
FRESULT SD_Close(void);
float SD_Get_Free_Space_Percentage(void);
float SD_Get_Used_Space_Percentage(void);
void SD_Check_Space(void);


int SD_disk_sync(void);
bool SD_select(void);
void SD_deselect(void);
HAL_StatusTypeDef SD_waitReady(int timeout);






#endif


