/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "fatfs.h"
#include "rtc.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "SIM800L.h"
#include "RF95.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
void Set_RTC_from_GPRS(void);
void Send_RTC_to_Slaves(uint16_t one_all);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
RTC_TimeTypeDef sTime = {0};
RTC_DateTypeDef sDate = {0};
RTC_AlarmTypeDef sAlarm = {0};

volatile bool Alarm_Flag = 0;

char Nombre_archivo[20] = {0};

FATFS fs;
FATFS *pfs;
FIL fil;
FRESULT fres;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_RTC_Init();
  MX_SPI1_Init();
  MX_SPI3_Init();
  MX_USART1_UART_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */
  	HAL_GPIO_WritePin(LM2596_EN_GPIO_Port, LM2596_EN_Pin, GPIO_PIN_RESET);
	while(SIM800_Init() != SIM800_OK) { } //Inicializamos el SIM800L

	Set_RTC_from_GPRS(); //Cargamos la hora desde el GPRS al microcontrolador
	HAL_GPIO_WritePin(LM2596_EN_GPIO_Port, LM2596_EN_Pin, GPIO_PIN_SET);
	Send_RTC_to_Slaves(1); //Enviamos la hora a las motas esclavas

	sprintf(Nombre_archivo, "JSON 20%d-%d-%d.txt", sDate.Year, sDate.Month, sDate.Date); //Inicializamos el nombre del archivo

	HAL_GPIO_WritePin(SD_SWITCH_GPIO_Port, SD_SWITCH_Pin, GPIO_PIN_RESET); //Alimentamos la SD
	/* Mount SD Card */
	if(f_mount(&fs, "", 0) != FR_OK) //Montamos el sistema de archivos
	{
	 Error_Handler();
	}

	/* Open file to write */
	if(f_open(&fil, Nombre_archivo, FA_OPEN_APPEND | FA_WRITE) != FR_OK) //Abrimos el archivo
	{
	  Error_Handler();
	}

	f_puts("{\"IdMota\":\"MAlbacete1\",\n\"Datos\":[\n", &fil);  //Inicializamos el archivo

	if(f_mount(0, "", 0) !=FR_OK) //Desmontamos el sistema de archivos
	{
		Error_Handler();
	}

	if(f_close(&fil) !=FR_OK) //Cerramos el archivo
	{
		Error_Handler();
	}
	HAL_GPIO_WritePin(SD_SWITCH_GPIO_Port, SD_SWITCH_Pin, GPIO_PIN_SET); //Cortamos la alimentación a la tarjeta SD para prevenir el consumo excesivo

	sAlarm.AlarmTime.Hours = 23;
	sAlarm.AlarmTime.Minutes = 50;
	sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY | RTC_ALARMMASK_SECONDS;
	HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);  //Fijamos la alarma a las 23:50

	HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	if(Alarm_Flag == 1)
	{
		Alarm_Flag = 0;

		HAL_GPIO_WritePin(SD_SWITCH_GPIO_Port, SD_SWITCH_Pin, GPIO_PIN_RESET); //Alimentamos la SD
		/* Mount SD Card */
		if(f_mount(&fs, "", 0) != FR_OK) //Montamos el sistema de archivos
		{
		 Error_Handler();
		}

		/* Open file to write */
		if(f_open(&fil, Nombre_archivo, FA_OPEN_APPEND | FA_WRITE) != FR_OK) //Abrimos el archivo
		{
		  Error_Handler();
		}

		f_puts("{\"IdMota\":\"MAlbacete1\",\n\"Datos\":[\n", &fil);  //Inicializamos el archivo
		RF95_Master_Receive_from_Node(1);
		f_puts("\n]\n", &fil );

		f_puts("{\"IdMota\":\"MAlbacete2\",\n\"Datos\":[\n", &fil);  //Inicializamos el archivo
		RF95_Master_Receive_from_Node(2);
		f_puts("\n]\n}", &fil );

		if(f_close(&fil) !=FR_OK) //Cerramos el archivo
		{
			Error_Handler();
		}
		HAL_GPIO_WritePin(SD_SWITCH_GPIO_Port, SD_SWITCH_Pin, GPIO_PIN_SET); //Cortamos la alimentación a la tarjeta SD para prevenir el consumo excesivo

		HAL_GPIO_WritePin(LM2596_EN_GPIO_Port, LM2596_EN_Pin, GPIO_PIN_RESET);
		Set_RTC_from_GPRS();
		Send_RTC_to_Slaves(0);

		SIM800_FTP(Nombre_archivo);
		HAL_GPIO_WritePin(LM2596_EN_GPIO_Port, LM2596_EN_Pin, GPIO_PIN_SET);

		sAlarm.AlarmTime.Hours = 23;
		sAlarm.AlarmTime.Minutes = 50;
		sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY | RTC_ALARMMASK_SECONDS;
		HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);  //Fijamos la alarma a las 23:50

		HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
	}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure LSE Drive Capability 
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_LSE
                              |RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_USART1
                              |RCC_PERIPHCLK_ADC;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 16;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_ADC1CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable MSI Auto calibration 
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/* USER CODE BEGIN 4 */
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(hrtc);

  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_RTC_AlarmAEventCallback could be implemented in the user file
   */
	Alarm_Flag = 1;
}


void Set_RTC_from_GPRS(void)
{
	int time_date[6] = {0};

	SIM800_Get_Time_Date_GPRS(time_date);

	sDate.Year = time_date[0] - 2000;
	sDate.Month = time_date[1];
	sDate.Date = time_date[2];
	if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
	{
		Error_Handler();
	}

	sTime.Hours = time_date[3];
	sTime.Minutes = time_date[4];
	sTime.Seconds = time_date[5];
	if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
	{
		Error_Handler();
	}
}


void Send_RTC_to_Slaves(uint16_t one_all)
{
	uint8_t buff[25] = {0};

	if(one_all == 0)
	{
		HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
		HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
		sprintf(buff, "%d,%d,%d,%d,%d,%d", (int)sDate.Year, (int)sDate.Month, (int)sDate.Date, (int)sTime.Hours, (int)sTime.Minutes, (int)sTime.Seconds);
		RF95_Master_Send_to_All_Nodes(buff);
	}
	else
	{
		HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
		HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
		sprintf(buff, "%d,%d,%d,%d,%d,%d", (int)sDate.Year, (int)sDate.Month, (int)sDate.Date, (int)sTime.Hours, (int)sTime.Minutes, (int)sTime.Seconds);
		RF95_Master_Send_to_Node(one_all, buff);
	}

}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	SIM800_Callback(huart);
}







/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
